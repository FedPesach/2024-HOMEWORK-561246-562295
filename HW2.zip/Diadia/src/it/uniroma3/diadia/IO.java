package it.uniroma3.diadia;

public interface IO {
	public void mostraMessaggio(String messaggio);
	public String leggiRiga();
}
